Cathoder CRT Surface Shader

Version: 1.0
Author: Tpot [ https://twitter.com/SslTpot ]

For use with Unity 2018.1+.

Additional Credits:
 CRT Mesh: GreatLange [ https://twitter.com/GreatLange ]